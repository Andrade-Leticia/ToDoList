import controller.TarefasControle;
import model.Tarefas;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static TarefasControle controle = new TarefasControle();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcao = -1;

        while (opcao != 0) {
            System.out.println("\n=== To Do List :) ===");
            System.out.println("1. Listar tarefas");
            System.out.println("2. Adicionar tarefa");
            System.out.println("3. Editar tarefa");
            System.out.println("4. Excluir tarefa");
            System.out.println("5. Marcar tarefa como concluída");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");

            opcao = Integer.parseInt(scanner.nextLine());

            try {
                switch (opcao) {
                    case 1:
                        listarTarefas();
                        break;
                    case 2:
                        adicionarTarefa();
                        break;
                    case 3:
                        editarTarefa();
                        break;
                    case 4:
                        excluirTarefa();
                        break;
                    case 5:
                        concluirTarefa();
                        break;
                    case 0:
                        System.out.println("Encerrando o sistema...");
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            } catch (SQLException e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
    }

    private static void listarTarefas() throws SQLException {
        List<Tarefas> tarefas = controle.listar();
        System.out.println("\n=== Lista de Tarefas ===");
        for (Tarefas t : tarefas) {
            System.out.printf("ID: %d | Título: %s | Descrição: %s | Concluída: %s\n",
                    t.getId(), t.getTitulo(), t.getDescricao(), t.isStatus() ? "Sim" : "Não");
        }
    }

    private static void adicionarTarefa() throws SQLException {
        System.out.print("Título: ");
        String titulo = scanner.nextLine();
        System.out.print("Descrição: ");
        String descricao = scanner.nextLine();

        controle.adicionar(titulo, descricao);
        System.out.println("Tarefa adicionada com sucesso!");
    }

    private static void editarTarefa() throws SQLException {
        System.out.print("ID da tarefa a editar: ");
        int id = Integer.parseInt(scanner.nextLine());
        System.out.print("Novo título: ");
        String titulo = scanner.nextLine();
        System.out.print("Nova descrição: ");
        String descricao = scanner.nextLine();
        System.out.print("Está concluída? (s/n): ");
        boolean status = scanner.nextLine().equalsIgnoreCase("s");

        controle.editar(id, titulo, descricao, status);
        System.out.println("Tarefa atualizada com sucesso!");
    }

    private static void excluirTarefa() throws SQLException {
        System.out.print("ID da tarefa a excluir: ");
        int id = Integer.parseInt(scanner.nextLine());

        controle.excluir(id);
        System.out.println("Tarefa excluída com sucesso!");
    }

    private static void concluirTarefa() throws SQLException {
        System.out.print("ID da tarefa a marcar como concluída: ");
        int id = Integer.parseInt(scanner.nextLine());

        controle.concluir(id);
        System.out.println("Tarefa marcada como concluída!");
    }
}
