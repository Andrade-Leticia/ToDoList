package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexaoMySQL {
    private static ConexaoMySQL conexaoMySQL;
    private static Connection conexao;
    private ConexaoMySQL(){
        try {
            conexao = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/tdePOO?useSSL=false","root", "SQL2025#");
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
    }
    public static ConexaoMySQL getInstance(){
        if (conexaoMySQL == null){
            conexaoMySQL = new ConexaoMySQL();
        }
        return conexaoMySQL;
    }

    public Connection getConexao(){
        return this.conexao;
    }
}
